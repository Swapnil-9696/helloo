const mysql = require("mysql");
const Promise = require("bluebird");
Promise.promisifyAll(require("mysql/lib/Connection").prototype);

const dbinfo = {
  host: "localhost",
  user: "root",
  password: "root",
  database: "myexam",
};

const connection = mysql.createConnection(dbinfo);

connection.connect();

async function addUser(user) {
  const connection = mysql.createConnection(dbinfo);

  await connection.connectAsync();

  let sql = `insert into user(username, password) values (?, ?)`;

  await connection.queryAsync(sql, [user.username, user.password]);

  console.log("connection done..");
  await connection.endAsync();
}

async function selectUser() {
  const connection = mysql.createConnection(dbinfo);
  await connection.connectAsync();

  let sql = `select * from user`;

  const list = await connection.queryAsync(sql, []);

  await connection.endAsync();

  console.log(list);
  return list;
}

const user = { username: "sarvesh", password: "khunkharrrr" };

//addUser(user);
selectUser();

module.exports = { selectUser, addUser };
